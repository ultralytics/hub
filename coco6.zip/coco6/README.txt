# Introduction

This directory contains the COCO6 dataset as an example of how to structure a YOLOv5 dataset for Ultralytics HUB. 

For more information please visit https://ultralytics.com
